package cap01;

import javax.swing.JFrame;

public class LeImagem02 {

	public static void main(String[] args) {
		
		JFrame principal = new JFrame("Tela");
		principal.setSize(800, 600);
		principal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		principal.setLocationRelativeTo(null);
		principal.setVisible(true);
	}
}
