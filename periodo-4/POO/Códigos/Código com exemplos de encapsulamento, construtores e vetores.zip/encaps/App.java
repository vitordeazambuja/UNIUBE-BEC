package encaps;

import java.util.ArrayList;
import java.util.List;

public class App {
	public static void main(String[] args) {

		/*Cliente cliente = new Cliente("Clênio", "100.300.200-89", 28);
		
		Conta conta1 = new Conta(cliente);
		
		conta1.setTipo("Corrente");
		conta1.setSaldo(5000.00);
		

		conta1.mostraDadosConta();
		
		Conta conta2 = new Conta(cliente);*/
		
		
		Conta[] contas = new Conta[5];
		
		for(int i=0; i < 5; i++) {
			Cliente c = new Cliente("nome"+i, "100.300.200-8"+i, i*20);
			contas[i] = new Conta(c);
			contas[i].setTipo("Corrente");
			contas[i].setSaldo(5000.00 * (i + 1));
			
			
		}
		for(int i=0; i<5;i++) {
			contas[i].mostraDadosConta();
			
		}
		
		
		
	}

}
