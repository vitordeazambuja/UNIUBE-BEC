package encaps;

public class Conta {
	private String tipo;
	private double saldo;
	private Cliente cliente;
	
	public Conta(Cliente cliente) {
		this.cliente = cliente;
		
	}
		
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	public void mostraDadosConta() {
		System.out.println("Tipo: " + tipo + "\nSaldo: " + saldo);
		cliente.mostraDadosCliente();
		
		
	}
	
	
	

	

	
	

}
