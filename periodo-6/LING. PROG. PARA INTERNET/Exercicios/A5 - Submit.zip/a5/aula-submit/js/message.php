<?php
	
 	if ( isset ( $_GET['txt_mensagem'] ) ) {
		
		$message = $_GET['txt_mensagem'];
		 
		echo '{"data": "teste"}';
	}
	else {

		echo '{"error": "teste"}';
	}
?>

