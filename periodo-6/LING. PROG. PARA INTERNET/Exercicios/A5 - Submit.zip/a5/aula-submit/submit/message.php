<?php
	echo "GET:<br>";
	print_r($_GET);
	echo "<br><br>POST:<br>";
	print_r($_POST);
?>
