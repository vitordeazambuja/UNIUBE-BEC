var jogador = 1;
var vencedor = "";

function inicioApp() {

    var casas = document.querySelectorAll(".casa");

    casas.forEach(element => {

        element.addEventListener('click', clickCasa);
    });
}

function clickCasa(event) {

    // acessar elemento clicado
    var element = event.target;

    // obter backgound do elemento
    var bg = element.style.backgroundImage;

    // verificar se o background está vazio

    if (bg == "none" || bg == "") {

        // criar uma url para acessar a imagem determinada pela variável vez
        var back = "url('" + jogador + ".png')";

        // alterar background do elemento clicado
        element.style.backgroundImage = back;

        // alterar a variável vez (alternando de 1 para 2 ou de 2 para 1)
        if (jogador == 1) {
            jogador = 2;
        }
        else {
            jogador = 1;
        }

        // invocar método para verificar fim do jogo (tal método ainda será 
        // implementado). Apenas coloque a chamada dele.
        verificarFimDeJogo();
    }
}

function casasIguais(a, b, c) {

    // acessar o elemento do parâmetro 1 (id: "casa" + a)
    var elemA = document.getElementById('casa' + a);

    // acessar o elemento do parâmetro 2 (id: "casa" + b)
    var elemB = document.getElementById('casa' + b);

    // acessar o elemento do parâmetro 3 (id: "casa" + c)
    var elemC = document.getElementById('casa' + c);

    // acessar o backgroundImage do elemento de parâmetro 1 (id: "casa" + a)
    var bkA = elemA.style.backgroundImage;

    // acessar o backgroundImage do elemento de parâmetro 2 (id: "casa" + b)
    var bkB = elemB.style.backgroundImage;

    // acessar o backgroundImage do elemento de parâmetro 3 (id: "casa" + c)
    var bkC = elemC.style.backgroundImage;

    // se o primeiro elemento for nulo (none) ou em branco, retorna falso
    if (bkA == "none" || bkA == "") {

        return false;
    }

    // verificar se o backgroundImage dos três são iguais, se sim tem condição para 
    if (bkA == bkB && bkA == bkC) {

        // finalizar o jogo

        // verificar se o conteúdo do backgroundImage contém o arquivo 1
        //se sim, o vencedor é o jogador 1 (armazenar na variável global)
        if (bkA.indexOf('1') > -1) {
            vencedor = '1';
        }
        //se não, o vencedor é o jogador 2 (armazenar na variável global)
        else {
            vencedor = '2';
        }

        // retornar verdadeiro para indicar que as três casas determinam a 
        // finalização o jogo
        return true;
    }

    // retorna falso, pois com essas três casas o jogo não finaliza
    return false;
}

function verificarFimDeJogo() {
 
    // Verificar se algum trio de casas (que podem finalizar o jogo)
    // estão iguais
    if( casasIguais(1, 2, 3) || casasIguais(4,5,6) || casasIguais(7,8,9) || 
    casasIguais(1, 4, 7) || casasIguais(2, 5, 8) || casasIguais(3, 6, 9) ||
    casasIguais(1, 5, 9) || casasIguais(3, 5, 7) ) {
        // se sim, acessar o div de id resultado e apresentar uma mensagem que 
        //indica o fim do jogo e o número do ganhador.
        console.info( vencedor );
        document.getElementById( 'resultado' ).textContent = 'O jogador vencedor é o ' + vencedor;

    }
 
}



inicioApp();